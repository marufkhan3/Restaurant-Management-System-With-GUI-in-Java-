import java.io.*;
import java.util.*;

public class RestaurantManagementSystem {
    private HashMap<String, String> adminCredentials = new HashMap<>();
    private ArrayList<MenuItem> menu = new ArrayList<>();
    private ArrayList<Table> tables = new ArrayList<>();
    private ArrayList<Order> orders = new ArrayList<>();
    private double dailySales = 0.0;

    // Constructor
    public RestaurantManagementSystem() {
        initializeMenu();
        initializeTables();
    }

    // Initialize menu with default items
    private void initializeMenu() {
        menu.add(new MenuItem(1, "Chicken Biriyani", 200.0));
        menu.add(new MenuItem(2, "Coca-Cola", 30.0));
        menu.add(new MenuItem(3, "Beef Khichuri", 150.0));
        menu.add(new MenuItem(4, "Beef Polao", 170.0));
        menu.add(new MenuItem(5, "Mineral Water", 20.0));
    }

    // Initialize tables with default IDs
    private void initializeTables() {
        for (int i = 1; i <= 5; i++) {
            tables.add(new Table(i));
        }
    }

    // Admin Registration
    public boolean registerAdmin(String username, String password) {
        if (adminCredentials.containsKey(username)) {
            System.out.println("Admin with this username already exists.");
            return false;
        }
        adminCredentials.put(username, password);
        System.out.println("Admin registered successfully!");
        return true;
    }

    // Admin Login
    public boolean adminLogin(String username, String password) {
        if (adminCredentials.containsKey(username) && adminCredentials.get(username).equals(password)) {
            System.out.println("Login successful.");
            return true;
        }
        System.out.println("Invalid credentials. Please try again.");
        return false;
    }

    // Add Menu Item
    public void addMenuItem(int id, String name, double price) {
        menu.add(new MenuItem(id, name, price));
        System.out.println("Menu item added successfully.");
    }

    // View Menu
    public void viewMenu() {
        System.out.println("\n--- Menu ---");
        for (MenuItem item : menu) {
            System.out.println(item);
        }
    }

    // Add Table
    public void addTable(int id) {
        tables.add(new Table(id));
        System.out.println("Table added successfully.");
    }

    // View Available Tables
    public void viewTables() {
        System.out.println("\n--- Available Tables ---");
        for (Table table : tables) {
            if (!table.isOccupied()) {
                System.out.println(table);
            }
        }
    }

    // Assign Table to an Order
    public boolean assignTable(int tableId) {
        for (Table table : tables) {
            if (table.getId() == tableId && !table.isOccupied()) {
                table.setOccupied(true);
                System.out.println("Table " + tableId + " assigned successfully.");
                return true;
            }
        }
        System.out.println("Table " + tableId + " is not available.");
        return false;
    }

    // Free a Table
    public void freeTable(int tableId) {
        for (Table table : tables) {
            if (table.getId() == tableId) {
                table.setOccupied(false);
                System.out.println("Table " + tableId + " is now available.");
                return;
            }
        }
        System.out.println("Table " + tableId + " not found.");
    }

    // Method to retrieve a table by its ID
    public Table getTableById(int id) {
        for (Table table : tables) {
            if (table.getId() == id) {
                return table;
            }
        }
        return null; // Return null if no table is found with the given ID
    }

    // Create an Order
    public void createOrder(Order order) {
        orders.add(order);
        dailySales += order.calculateTotal(); // Add the total of the order to daily sales
        System.out.println("Order created successfully: " + order);
    }

    // Cancel an Order
    public boolean cancelOrder(String orderId) {
        Order orderToCancel = null;

        // Locate the order by its ID
        for (Order order : orders) {
            if (order.getOrderId().equals(orderId)) {
                orderToCancel = order;
                break;
            }
        }

        if (orderToCancel == null) {
            System.out.println("Order ID " + orderId + " not found.");
            return false;
        }

        // Free the associated table
        freeTable(orderToCancel.getTableId());

        // Subtract the total price of the canceled order from daily sales
        dailySales -= orderToCancel.calculateTotal();

        // Remove the order
        orders.remove(orderToCancel);
        System.out.println("Order " + orderId + " has been canceled.");
        return true;
    }

    // View All Active Orders
    public void viewOrders() {
        System.out.println("\n--- Active Orders ---");
        if (orders.isEmpty()) {
            System.out.println("No active orders.");
        } else {
            for (Order order : orders) {
                System.out.println(order);
            }
        }
    }

    // View Daily Sales
    public void viewSales() {
        System.out.println("Total Daily Sales: " + dailySales + " Taka");
    }

    // Add sales to the daily total
    public void addSales(double sales) {
        dailySales += sales; // Adds sales to the daily total
        System.out.println("Sales of " + sales + " Taka added to daily sales.");
    }

    // Save data to files
    public void saveData() throws IOException {
        // Save tables
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("tables.txt"))) {
            for (Table table : tables) {
                writer.write(table.toString());
                writer.newLine();
            }
        }

        // Save menu
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("menu.txt"))) {
            for (MenuItem item : menu) {
                writer.write(item.toString());
                writer.newLine();
            }
        }

        // Save sales
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("sales.txt"))) {
            writer.write(String.valueOf(dailySales));
        }
    }

    // Load data from files
    public void loadData() throws IOException {


        // Load sales
        try (BufferedReader reader = new BufferedReader(new FileReader("sales.txt"))) {
            String line = reader.readLine();
            if (line != null) {
                dailySales = Double.parseDouble(line);
            }
        }
    }

    // Getters
    public ArrayList<MenuItem> getMenu() {
        return menu;
    }

    public ArrayList<Table> getTables() {
        return tables;
    }

    public ArrayList<Order> getOrders() {
        return orders;
    }

    public double getDailySales() {
        return dailySales;
    }
}
