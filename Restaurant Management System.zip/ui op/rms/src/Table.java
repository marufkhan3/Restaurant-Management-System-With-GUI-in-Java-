import java.io.Serializable;

public class Table implements Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private boolean occupied;

    public Table(int id) {
        this.id = id;
        this.occupied = false;
    }

    public int getId() {
        return id;
    }

    public boolean isOccupied() {
        return occupied;
    }

    public void setOccupied(boolean occupied) {
        this.occupied = occupied;
    }

    // Static fromString method to convert a string into a Table object
    public static Table fromString(String line) {
        String[] parts = line.split(", ");
        int id = Integer.parseInt(parts[0]);
        boolean isOccupied = Boolean.parseBoolean(parts[1]);
        Table table = new Table(id);
        table.setOccupied(isOccupied);
        return table;
    }

    @Override
    public String toString() {
        return "Table " + id + (occupied ? " (Occupied)" : " (Available)");
    }
}
