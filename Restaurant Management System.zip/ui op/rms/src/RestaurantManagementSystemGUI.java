import javax.swing.*;
import java.awt.*;
import java.io.*;
import java.util.ArrayList;

public class RestaurantManagementSystemGUI {

    private JFrame frame;
    private JPanel mainPanel, adminPanel, customerPanel;
    private RestaurantManagementSystem rms;

    public RestaurantManagementSystemGUI() {
        rms = new RestaurantManagementSystem();
        loadData(); // Load data from files at startup
        frame = new JFrame("Restaurant Management System");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        mainPanel = new JPanel();
        adminPanel = new JPanel();
        customerPanel = new JPanel();

        // Set up the main panel
        mainPanel.setLayout(new GridLayout(4, 1));
        JButton btnRegisterAdmin = new JButton("Register Admin");
        JButton btnAdminLogin = new JButton("Admin Panel");
        JButton btnCustomerPanel = new JButton("Customer Panel");
        JButton btnExit = new JButton("Exit");

        mainPanel.add(btnRegisterAdmin);
        mainPanel.add(btnAdminLogin);
        mainPanel.add(btnCustomerPanel);
        mainPanel.add(btnExit);

        // Action Listeners
        btnRegisterAdmin.addActionListener(e -> showAdminRegisterPanel());
        btnAdminLogin.addActionListener(e -> showAdminLoginPanel());
        btnCustomerPanel.addActionListener(e -> showCustomerPanel());
        btnExit.addActionListener(e -> {
            saveData(); // Save data before exiting
            System.exit(0);
        });

        // Set up the Admin Panel
        adminPanel.setLayout(new GridLayout(5, 1));
        JButton btnAddTable = new JButton("Add Table");
        JButton btnAddMenuItem = new JButton("Add Menu Item");
        JButton btnViewSales = new JButton("View Sales");
        JButton btnViewOrders = new JButton("View Orders");
        JButton btnLogoutAdmin = new JButton("Logout");

        adminPanel.add(btnAddTable);
        adminPanel.add(btnAddMenuItem);
        adminPanel.add(btnViewSales);
        adminPanel.add(btnViewOrders);
        adminPanel.add(btnLogoutAdmin);

        // Action Listeners for Admin Panel
        btnAddTable.addActionListener(e -> addTable());
        btnAddMenuItem.addActionListener(e -> addMenuItem());
        btnViewSales.addActionListener(e -> viewSales());
        btnViewOrders.addActionListener(e -> viewOrders());
        btnLogoutAdmin.addActionListener(e -> showMainMenu());

        // Set up the Customer Panel
        customerPanel.setLayout(new GridLayout(5, 1));
        JButton btnViewMenu = new JButton("View Menu");
        JButton btnPlaceOrder = new JButton("Place Order");
        JButton btnCancelOrder = new JButton("Cancel Order");
        JButton btnViewTables = new JButton("View Table Availability");
        JButton btnBackToMain = new JButton("Back to Main Menu");

        customerPanel.add(btnViewMenu);
        customerPanel.add(btnPlaceOrder);
        customerPanel.add(btnCancelOrder);
        customerPanel.add(btnViewTables);
        customerPanel.add(btnBackToMain);

        // Action Listeners for Customer Panel
        btnViewMenu.addActionListener(e -> viewMenu());
        btnPlaceOrder.addActionListener(e -> placeOrder());
        btnCancelOrder.addActionListener(e -> cancelOrder());
        btnViewTables.addActionListener(e -> viewTableAvailability());
        btnBackToMain.addActionListener(e -> showMainMenu());

        // Display the main panel initially
        frame.setContentPane(mainPanel);
        frame.setVisible(true);
    }

    private void showAdminRegisterPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 2));
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        panel.add(new JLabel("Enter Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Enter Password:"));
        panel.add(passwordField);

        JButton btnRegister = new JButton("Register");
        panel.add(btnRegister);

        btnRegister.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            if (rms.registerAdmin(username, password)) {
                JOptionPane.showMessageDialog(frame, "Admin Registered Successfully");
                showMainMenu();
            } else {
                JOptionPane.showMessageDialog(frame, "Admin already exists.");
            }
        });

        int option = JOptionPane.showConfirmDialog(frame, panel, "Admin Registration", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.CANCEL_OPTION) {
            showMainMenu();
        }
    }

    private void showAdminLoginPanel() {
        JPanel panel = new JPanel(new GridLayout(3, 2));
        JTextField usernameField = new JTextField();
        JPasswordField passwordField = new JPasswordField();

        panel.add(new JLabel("Enter Username:"));
        panel.add(usernameField);
        panel.add(new JLabel("Enter Password:"));
        panel.add(passwordField);

        JButton btnLogin = new JButton("Login");
        panel.add(btnLogin);

        btnLogin.addActionListener(e -> {
            String username = usernameField.getText();
            String password = new String(passwordField.getPassword());
            if (rms.adminLogin(username, password)) {
                showAdminPanel();
            } else {
                JOptionPane.showMessageDialog(frame, "Invalid credentials.");
            }
        });

        int option = JOptionPane.showConfirmDialog(frame, panel, "Admin Login", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
        if (option == JOptionPane.CANCEL_OPTION) {
            showMainMenu();
        }
    }

    private void showCustomerPanel() {
        frame.setContentPane(customerPanel);
        frame.revalidate();
    }

    private void showAdminPanel() {
        frame.setContentPane(adminPanel);
        frame.revalidate();
    }

    private void showMainMenu() {
        frame.setContentPane(mainPanel);
        frame.revalidate();
    }

    private void addMenuItem() {
        String itemName = JOptionPane.showInputDialog("Enter Item Name:");
        String itemPrice = JOptionPane.showInputDialog("Enter Item Price:");
        try {
            int id = rms.getMenu().size() + 1;
            double price = Double.parseDouble(itemPrice);
            rms.addMenuItem(id, itemName, price);
            saveData();
            JOptionPane.showMessageDialog(frame, "Menu item added successfully.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid price entered.");
        }
    }

    private void viewMenu() {
        StringBuilder menuText = new StringBuilder("Menu:\n");
        for (MenuItem item : rms.getMenu()) {
            menuText.append(item).append("\n");
        }
        JOptionPane.showMessageDialog(frame, menuText.toString());
    }

    private void placeOrder() {
        String tableId = JOptionPane.showInputDialog("Enter Table ID:");
        try {
            int id = Integer.parseInt(tableId);
            if (rms.assignTable(id)) {
                String itemIds = JOptionPane.showInputDialog("Enter Item IDs (comma-separated):");
                String[] itemIdArray = itemIds.split(",");

                Order order = new Order(id);
                for (String itemId : itemIdArray) {
                    for (MenuItem item : rms.getMenu()) {
                        if (item.getId() == Integer.parseInt(itemId.trim())) {
                            order.addItem(item);
                        }
                    }
                }

                rms.createOrder(order);
                saveData();
                JOptionPane.showMessageDialog(frame, "Order placed successfully! Your Order ID: " + order.getOrderId());
            } else {
                JOptionPane.showMessageDialog(frame, "Table not available.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid Table ID.");
        }
    }

    private void cancelOrder() {
        String orderId = JOptionPane.showInputDialog("Enter Order ID to cancel:");
        if (rms.cancelOrder(orderId)) {
            saveData();
            JOptionPane.showMessageDialog(frame, "Order canceled successfully. Table is now available.");
        } else {
            JOptionPane.showMessageDialog(frame, "Order ID not found.");
        }
    }

    private void viewTableAvailability() {
        StringBuilder tableStatus = new StringBuilder("Table Availability:\n");
        for (Table table : rms.getTables()) {
            tableStatus.append("Table ID: ").append(table.getId())
                    .append(" - ").append(table.isOccupied() ? "Reserved" : "Available").append("\n");
        }
        JOptionPane.showMessageDialog(frame, tableStatus.toString());
    }

    private void viewSales() {
        JOptionPane.showMessageDialog(frame, "Daily Sales: " + rms.getDailySales() + " Taka");
    }

    private void viewOrders() {
        StringBuilder orderText = new StringBuilder("Active Orders:\n");
        for (Order order : rms.getOrders()) {
            orderText.append(order).append("\n");
        }
        JOptionPane.showMessageDialog(frame, orderText.toString());
    }

    private void addTable() {
        String tableIdStr = JOptionPane.showInputDialog("Enter Table ID:");
        try {
            int tableId = Integer.parseInt(tableIdStr);
            rms.addTable(tableId);
            saveData();
            JOptionPane.showMessageDialog(frame, "Table added successfully.");
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(frame, "Invalid Table ID.");
        }
    }

    private void loadData() {
        try {

            // Load Sales
            File salesFile = new File("sales.txt");
            if (salesFile.exists()) {
                BufferedReader br = new BufferedReader(new FileReader(salesFile));
                String line;
                while ((line = br.readLine()) != null) {
                    double sales = Double.parseDouble(line.trim());
                    rms.addSales(sales);
                }
                br.close();
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error loading data: " + e.getMessage());
        }
    }

    private void saveData() {
        try {

            // Save Sales
            File salesFile = new File("sales.txt");
            BufferedWriter salesWriter = new BufferedWriter(new FileWriter(salesFile));
            salesWriter.write(String.valueOf(rms.getDailySales()));
            salesWriter.newLine();
            salesWriter.close();

        } catch (IOException e) {
            JOptionPane.showMessageDialog(frame, "Error saving data: " + e.getMessage());
        }
    }


    public static void main(String[] args) {
        SwingUtilities.invokeLater(RestaurantManagementSystemGUI::new);
    }
}
