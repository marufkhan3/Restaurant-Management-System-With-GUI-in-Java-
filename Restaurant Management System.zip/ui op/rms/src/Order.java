import java.util.ArrayList;

public class Order {
    private String orderId;
    private ArrayList<MenuItem> items;
    private int tableId; // Add this field

    public Order(int tableId) {
        this.tableId = tableId; // Initialize table ID
        this.items = new ArrayList<>();
        this.orderId = generateOrderId(); // Assume you have a method to generate unique IDs
    }

    public int getTableId() {
        return tableId;
    }

    public void addItem(MenuItem item) {
        items.add(item);
    }

    public String getOrderId() {
        return orderId;
    }

    public double calculateTotal() {
        double total = 0.0;
        for (MenuItem item : items) {
            total += item.getPrice();
        }
        return total;
    }

    @Override
    public String toString() {
        return "Order ID: " + orderId + ", Table ID: " + tableId + ", Items: " + items;
    }

    private String generateOrderId() {
        // Unique order ID generation logic
        return "ORD" + System.currentTimeMillis();
    }
}
