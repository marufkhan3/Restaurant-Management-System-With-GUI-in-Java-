public class MenuItem {
    private int id;
    private String name;
    private double price;

    public MenuItem(int id, String name, double price) {
        this.id = id;
        this.name = name;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    // Static fromString method to convert a string into a MenuItem object
    public static MenuItem fromString(String line) {
        String[] parts = line.split(", ");
        int id = Integer.parseInt(parts[0]);
        String name = parts[1];
        double price = Double.parseDouble(parts[2]);
        return new MenuItem(id, name, price);
    }

    @Override
    public String toString() {
        return "Item ID: " + id + ", Name: " + name + ", Price: " + price;
    }
}
